<?
	$url = "http://$_SERVER[HTTP_HOST]/asan/";
?>
<!-- start of footer-->
<div id="footer" align="center">	
	<img src="<?=$url?>/img/footercopyrighter.png" alt="푸터">
</div><!-- end of footer -->	
</body>
</html>